﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgvOrders = new System.Windows.Forms.DataGridView();
            this.номерЗаказаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.книгаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датаЗаказаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.количествоDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.покупательDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.суммаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderStatBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bookStoreDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bookStoreDataSet = new WindowsFormsApp2.BookStoreDataSet();
            this.gbSortBy = new System.Windows.Forms.GroupBox();
            this.rbTotalAmount = new System.Windows.Forms.RadioButton();
            this.rbQuantity = new System.Windows.Forms.RadioButton();
            this.rbBook = new System.Windows.Forms.RadioButton();
            this.rbCustomer = new System.Windows.Forms.RadioButton();
            this.rbOrderDate = new System.Windows.Forms.RadioButton();
            this.rbOrderId = new System.Windows.Forms.RadioButton();
            this.gbDirection = new System.Windows.Forms.GroupBox();
            this.rbDescending = new System.Windows.Forms.RadioButton();
            this.rbAscending = new System.Windows.Forms.RadioButton();
            this.gbSearch = new System.Windows.Forms.GroupBox();
            this.btnClearSearch = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnApplySort = new System.Windows.Forms.Button();
            this.lblSortInfo = new System.Windows.Forms.Label();
            this.orderStatTableAdapter = new WindowsFormsApp2.BookStoreDataSetTableAdapters.OrderStatTableAdapter();
            this.customersComboBox = new System.Windows.Forms.ComboBox();
            this.orderStatBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.gbCustomerFilter = new System.Windows.Forms.GroupBox();
            this.btnClearCustomerFilter = new System.Windows.Forms.Button();
            this.btnApplyCustomerFilter = new System.Windows.Forms.Button();
            this.bookStoreDataSet1 = new WindowsFormsApp2.BookStoreDataSet1();
            this.customersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.customersTableAdapter = new WindowsFormsApp2.BookStoreDataSet1TableAdapters.CustomersTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrders)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderStatBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookStoreDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookStoreDataSet)).BeginInit();
            this.gbSortBy.SuspendLayout();
            this.gbDirection.SuspendLayout();
            this.gbSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.orderStatBindingSource1)).BeginInit();
            this.gbCustomerFilter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bookStoreDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvOrders
            // 
            this.dgvOrders.AllowUserToAddRows = false;
            this.dgvOrders.AllowUserToDeleteRows = false;
            this.dgvOrders.AutoGenerateColumns = false;
            this.dgvOrders.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvOrders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOrders.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.номерЗаказаDataGridViewTextBoxColumn,
            this.книгаDataGridViewTextBoxColumn,
            this.датаЗаказаDataGridViewTextBoxColumn,
            this.количествоDataGridViewTextBoxColumn,
            this.покупательDataGridViewTextBoxColumn,
            this.суммаDataGridViewTextBoxColumn});
            this.dgvOrders.DataSource = this.orderStatBindingSource;
            this.dgvOrders.Location = new System.Drawing.Point(12, 175);
            this.dgvOrders.Name = "dgvOrders";
            this.dgvOrders.ReadOnly = true;
            this.dgvOrders.Size = new System.Drawing.Size(946, 289);
            this.dgvOrders.TabIndex = 0;
            this.dgvOrders.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvOrders_CellContentClick);
            // 
            // номерЗаказаDataGridViewTextBoxColumn
            // 
            this.номерЗаказаDataGridViewTextBoxColumn.DataPropertyName = "Номер заказа";
            this.номерЗаказаDataGridViewTextBoxColumn.HeaderText = "Номер заказа";
            this.номерЗаказаDataGridViewTextBoxColumn.Name = "номерЗаказаDataGridViewTextBoxColumn";
            this.номерЗаказаDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // книгаDataGridViewTextBoxColumn
            // 
            this.книгаDataGridViewTextBoxColumn.DataPropertyName = "Книга";
            this.книгаDataGridViewTextBoxColumn.HeaderText = "Книга";
            this.книгаDataGridViewTextBoxColumn.Name = "книгаDataGridViewTextBoxColumn";
            this.книгаDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // датаЗаказаDataGridViewTextBoxColumn
            // 
            this.датаЗаказаDataGridViewTextBoxColumn.DataPropertyName = "Дата заказа";
            this.датаЗаказаDataGridViewTextBoxColumn.HeaderText = "Дата заказа";
            this.датаЗаказаDataGridViewTextBoxColumn.Name = "датаЗаказаDataGridViewTextBoxColumn";
            this.датаЗаказаDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // количествоDataGridViewTextBoxColumn
            // 
            this.количествоDataGridViewTextBoxColumn.DataPropertyName = "Количество";
            this.количествоDataGridViewTextBoxColumn.HeaderText = "Количество";
            this.количествоDataGridViewTextBoxColumn.Name = "количествоDataGridViewTextBoxColumn";
            this.количествоDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // покупательDataGridViewTextBoxColumn
            // 
            this.покупательDataGridViewTextBoxColumn.DataPropertyName = "Покупатель";
            this.покупательDataGridViewTextBoxColumn.HeaderText = "Покупатель";
            this.покупательDataGridViewTextBoxColumn.Name = "покупательDataGridViewTextBoxColumn";
            this.покупательDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // суммаDataGridViewTextBoxColumn
            // 
            this.суммаDataGridViewTextBoxColumn.DataPropertyName = "Сумма";
            this.суммаDataGridViewTextBoxColumn.HeaderText = "Сумма";
            this.суммаDataGridViewTextBoxColumn.Name = "суммаDataGridViewTextBoxColumn";
            this.суммаDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // orderStatBindingSource
            // 
            this.orderStatBindingSource.DataMember = "OrderStat";
            this.orderStatBindingSource.DataSource = this.bookStoreDataSetBindingSource;
            // 
            // bookStoreDataSetBindingSource
            // 
            this.bookStoreDataSetBindingSource.DataSource = this.bookStoreDataSet;
            this.bookStoreDataSetBindingSource.Position = 0;
            // 
            // bookStoreDataSet
            // 
            this.bookStoreDataSet.DataSetName = "BookStoreDataSet";
            this.bookStoreDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // gbSortBy
            // 
            this.gbSortBy.Controls.Add(this.rbTotalAmount);
            this.gbSortBy.Controls.Add(this.rbQuantity);
            this.gbSortBy.Controls.Add(this.rbBook);
            this.gbSortBy.Controls.Add(this.rbCustomer);
            this.gbSortBy.Controls.Add(this.rbOrderDate);
            this.gbSortBy.Controls.Add(this.rbOrderId);
            this.gbSortBy.Location = new System.Drawing.Point(28, 12);
            this.gbSortBy.Name = "gbSortBy";
            this.gbSortBy.Size = new System.Drawing.Size(294, 69);
            this.gbSortBy.TabIndex = 1;
            this.gbSortBy.TabStop = false;
            this.gbSortBy.Text = "Сортировка по:";
            // 
            // rbTotalAmount
            // 
            this.rbTotalAmount.AutoSize = true;
            this.rbTotalAmount.Location = new System.Drawing.Point(200, 42);
            this.rbTotalAmount.Name = "rbTotalAmount";
            this.rbTotalAmount.Size = new System.Drawing.Size(59, 17);
            this.rbTotalAmount.TabIndex = 5;
            this.rbTotalAmount.TabStop = true;
            this.rbTotalAmount.Text = "Сумма";
            this.rbTotalAmount.UseVisualStyleBackColor = true;
            // 
            // rbQuantity
            // 
            this.rbQuantity.AutoSize = true;
            this.rbQuantity.Location = new System.Drawing.Point(104, 42);
            this.rbQuantity.Name = "rbQuantity";
            this.rbQuantity.Size = new System.Drawing.Size(84, 17);
            this.rbQuantity.TabIndex = 4;
            this.rbQuantity.TabStop = true;
            this.rbQuantity.Text = "Количество";
            this.rbQuantity.UseVisualStyleBackColor = true;
            // 
            // rbBook
            // 
            this.rbBook.AutoSize = true;
            this.rbBook.Location = new System.Drawing.Point(6, 42);
            this.rbBook.Name = "rbBook";
            this.rbBook.Size = new System.Drawing.Size(55, 17);
            this.rbBook.TabIndex = 3;
            this.rbBook.TabStop = true;
            this.rbBook.Text = "Книга";
            this.rbBook.UseVisualStyleBackColor = true;
            // 
            // rbCustomer
            // 
            this.rbCustomer.AutoSize = true;
            this.rbCustomer.Location = new System.Drawing.Point(200, 19);
            this.rbCustomer.Name = "rbCustomer";
            this.rbCustomer.Size = new System.Drawing.Size(85, 17);
            this.rbCustomer.TabIndex = 2;
            this.rbCustomer.TabStop = true;
            this.rbCustomer.Text = "Покупатель";
            this.rbCustomer.UseVisualStyleBackColor = true;
            // 
            // rbOrderDate
            // 
            this.rbOrderDate.AutoSize = true;
            this.rbOrderDate.Location = new System.Drawing.Point(104, 19);
            this.rbOrderDate.Name = "rbOrderDate";
            this.rbOrderDate.Size = new System.Drawing.Size(90, 17);
            this.rbOrderDate.TabIndex = 1;
            this.rbOrderDate.TabStop = true;
            this.rbOrderDate.Text = "Дата заказа";
            this.rbOrderDate.UseVisualStyleBackColor = true;
            // 
            // rbOrderId
            // 
            this.rbOrderId.AutoSize = true;
            this.rbOrderId.Location = new System.Drawing.Point(6, 19);
            this.rbOrderId.Name = "rbOrderId";
            this.rbOrderId.Size = new System.Drawing.Size(98, 17);
            this.rbOrderId.TabIndex = 0;
            this.rbOrderId.TabStop = true;
            this.rbOrderId.Text = "Номер заказа";
            this.rbOrderId.UseVisualStyleBackColor = true;
            // 
            // gbDirection
            // 
            this.gbDirection.Controls.Add(this.rbDescending);
            this.gbDirection.Controls.Add(this.rbAscending);
            this.gbDirection.Location = new System.Drawing.Point(328, 12);
            this.gbDirection.Name = "gbDirection";
            this.gbDirection.Size = new System.Drawing.Size(121, 69);
            this.gbDirection.TabIndex = 6;
            this.gbDirection.TabStop = false;
            this.gbDirection.Text = "Направление";
            // 
            // rbDescending
            // 
            this.rbDescending.AutoSize = true;
            this.rbDescending.Location = new System.Drawing.Point(6, 42);
            this.rbDescending.Name = "rbDescending";
            this.rbDescending.Size = new System.Drawing.Size(93, 17);
            this.rbDescending.TabIndex = 1;
            this.rbDescending.TabStop = true;
            this.rbDescending.Text = "По убыванию";
            this.rbDescending.UseVisualStyleBackColor = true;
            // 
            // rbAscending
            // 
            this.rbAscending.AutoSize = true;
            this.rbAscending.Location = new System.Drawing.Point(6, 19);
            this.rbAscending.Name = "rbAscending";
            this.rbAscending.Size = new System.Drawing.Size(109, 17);
            this.rbAscending.TabIndex = 0;
            this.rbAscending.TabStop = true;
            this.rbAscending.Text = "По возрастанию";
            this.rbAscending.UseVisualStyleBackColor = true;
            // 
            // gbSearch
            // 
            this.gbSearch.Controls.Add(this.btnClearSearch);
            this.gbSearch.Controls.Add(this.btnSearch);
            this.gbSearch.Controls.Add(this.txtSearch);
            this.gbSearch.Location = new System.Drawing.Point(455, 12);
            this.gbSearch.Name = "gbSearch";
            this.gbSearch.Size = new System.Drawing.Size(421, 78);
            this.gbSearch.TabIndex = 7;
            this.gbSearch.TabStop = false;
            this.gbSearch.Text = "Поиск по названию книги";
            // 
            // btnClearSearch
            // 
            this.btnClearSearch.Location = new System.Drawing.Point(107, 45);
            this.btnClearSearch.Name = "btnClearSearch";
            this.btnClearSearch.Size = new System.Drawing.Size(95, 21);
            this.btnClearSearch.TabIndex = 2;
            this.btnClearSearch.Text = "Сброс";
            this.btnClearSearch.UseVisualStyleBackColor = true;
            this.btnClearSearch.Click += new System.EventHandler(this.btnClearSearch_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(6, 45);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(95, 21);
            this.btnSearch.TabIndex = 1;
            this.btnSearch.Text = "Найти";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(6, 19);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(409, 20);
            this.txtSearch.TabIndex = 0;
            this.txtSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearch_KeyDown);
            // 
            // btnApplySort
            // 
            this.btnApplySort.Location = new System.Drawing.Point(328, 96);
            this.btnApplySort.Name = "btnApplySort";
            this.btnApplySort.Size = new System.Drawing.Size(196, 21);
            this.btnApplySort.TabIndex = 3;
            this.btnApplySort.Text = "Применить сортировку";
            this.btnApplySort.UseVisualStyleBackColor = true;
            this.btnApplySort.Click += new System.EventHandler(this.btnApplySort_Click);
            // 
            // lblSortInfo
            // 
            this.lblSortInfo.AutoSize = true;
            this.lblSortInfo.Location = new System.Drawing.Point(331, 120);
            this.lblSortInfo.Name = "lblSortInfo";
            this.lblSortInfo.Size = new System.Drawing.Size(107, 13);
            this.lblSortInfo.TabIndex = 8;
            this.lblSortInfo.Text = "Данные загружены";
            // 
            // orderStatTableAdapter
            // 
            this.orderStatTableAdapter.ClearBeforeFill = true;
            // 
            // customersComboBox
            // 
            this.customersComboBox.DataSource = this.customersBindingSource;
            this.customersComboBox.DisplayMember = "FullName";
            this.customersComboBox.FormattingEnabled = true;
            this.customersComboBox.Location = new System.Drawing.Point(6, 19);
            this.customersComboBox.Name = "customersComboBox";
            this.customersComboBox.Size = new System.Drawing.Size(279, 21);
            this.customersComboBox.TabIndex = 3;
            // 
            // orderStatBindingSource1
            // 
            this.orderStatBindingSource1.DataMember = "OrderStat";
            this.orderStatBindingSource1.DataSource = this.bookStoreDataSetBindingSource;
            // 
            // gbCustomerFilter
            // 
            this.gbCustomerFilter.Controls.Add(this.btnClearCustomerFilter);
            this.gbCustomerFilter.Controls.Add(this.customersComboBox);
            this.gbCustomerFilter.Controls.Add(this.btnApplyCustomerFilter);
            this.gbCustomerFilter.Location = new System.Drawing.Point(28, 87);
            this.gbCustomerFilter.Name = "gbCustomerFilter";
            this.gbCustomerFilter.Size = new System.Drawing.Size(294, 82);
            this.gbCustomerFilter.TabIndex = 9;
            this.gbCustomerFilter.TabStop = false;
            this.gbCustomerFilter.Text = "Фильтр по покупателю";
            // 
            // btnClearCustomerFilter
            // 
            this.btnClearCustomerFilter.Location = new System.Drawing.Point(110, 46);
            this.btnClearCustomerFilter.Name = "btnClearCustomerFilter";
            this.btnClearCustomerFilter.Size = new System.Drawing.Size(95, 21);
            this.btnClearCustomerFilter.TabIndex = 4;
            this.btnClearCustomerFilter.Text = "Сброс";
            this.btnClearCustomerFilter.UseVisualStyleBackColor = true;
            this.btnClearCustomerFilter.Click += new System.EventHandler(this.btnClearCustomerFilter_Click);
            // 
            // btnApplyCustomerFilter
            // 
            this.btnApplyCustomerFilter.Location = new System.Drawing.Point(9, 46);
            this.btnApplyCustomerFilter.Name = "btnApplyCustomerFilter";
            this.btnApplyCustomerFilter.Size = new System.Drawing.Size(95, 21);
            this.btnApplyCustomerFilter.TabIndex = 3;
            this.btnApplyCustomerFilter.Text = "Найти";
            this.btnApplyCustomerFilter.UseVisualStyleBackColor = true;
            this.btnApplyCustomerFilter.Click += new System.EventHandler(this.btnApplyCustomerFilter_Click);
            // 
            // bookStoreDataSet1
            // 
            this.bookStoreDataSet1.DataSetName = "BookStoreDataSet1";
            this.bookStoreDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customersBindingSource
            // 
            this.customersBindingSource.DataMember = "Customers";
            this.customersBindingSource.DataSource = this.bookStoreDataSet1;
            // 
            // customersTableAdapter
            // 
            this.customersTableAdapter.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(970, 477);
            this.Controls.Add(this.gbCustomerFilter);
            this.Controls.Add(this.lblSortInfo);
            this.Controls.Add(this.btnApplySort);
            this.Controls.Add(this.gbSearch);
            this.Controls.Add(this.gbDirection);
            this.Controls.Add(this.gbSortBy);
            this.Controls.Add(this.dgvOrders);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrders)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderStatBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookStoreDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookStoreDataSet)).EndInit();
            this.gbSortBy.ResumeLayout(false);
            this.gbSortBy.PerformLayout();
            this.gbDirection.ResumeLayout(false);
            this.gbDirection.PerformLayout();
            this.gbSearch.ResumeLayout(false);
            this.gbSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.orderStatBindingSource1)).EndInit();
            this.gbCustomerFilter.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bookStoreDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvOrders;
        private System.Windows.Forms.BindingSource bookStoreDataSetBindingSource;
        private BookStoreDataSet bookStoreDataSet;
        private System.Windows.Forms.BindingSource orderStatBindingSource;
        private BookStoreDataSetTableAdapters.OrderStatTableAdapter orderStatTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерЗаказаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn книгаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаЗаказаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn покупательDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn суммаDataGridViewTextBoxColumn;
        private System.Windows.Forms.GroupBox gbSortBy;
        private System.Windows.Forms.RadioButton rbTotalAmount;
        private System.Windows.Forms.RadioButton rbQuantity;
        private System.Windows.Forms.RadioButton rbBook;
        private System.Windows.Forms.RadioButton rbCustomer;
        private System.Windows.Forms.RadioButton rbOrderDate;
        private System.Windows.Forms.RadioButton rbOrderId;
        private System.Windows.Forms.GroupBox gbDirection;
        private System.Windows.Forms.RadioButton rbDescending;
        private System.Windows.Forms.RadioButton rbAscending;
        private System.Windows.Forms.GroupBox gbSearch;
        private System.Windows.Forms.Button btnClearSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnApplySort;
        private System.Windows.Forms.Label lblSortInfo;
        private System.Windows.Forms.ComboBox customersComboBox;
        private System.Windows.Forms.BindingSource orderStatBindingSource1;
        private System.Windows.Forms.GroupBox gbCustomerFilter;
        private System.Windows.Forms.Button btnClearCustomerFilter;
        private System.Windows.Forms.Button btnApplyCustomerFilter;
        private BookStoreDataSet1 bookStoreDataSet1;
        private System.Windows.Forms.BindingSource customersBindingSource;
        private BookStoreDataSet1TableAdapters.CustomersTableAdapter customersTableAdapter;
    }
}

